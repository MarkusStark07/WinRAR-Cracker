package net.MarkusStark07.winrarcrack;

import net.MarkusStark07.winrarcrack.GUI.MainGUI;

public class Main {

    public static void main(String args[]) {
        new MainGUI();
    }
}
